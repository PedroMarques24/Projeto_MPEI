%% Ainda não funciona porque está a implementar variáveis do Naive Bayes 
% Temos de ver isso melhor

clear

data = readtable('electronics.csv');

data = data(~any(ismissing(data), 2), {'user_id', 'item_id', 'category', 'rating', 'brand'});

% ---- Bloom Filter: Eliminar Produtos Já Comprados ----

% Inicializar o Bloom Filter para a categoria prevista
muito_bit = 1000; 
filtro = false(1, muito_bit); 
hash_function = @(x) mod(sum(double(x)), muito_bit) + 1;

% Filtrar os produtos da categoria prevista
category_data = data(strcmp(data.category, nomes_previstos), :);

% Adicionar os produtos já comprados do usuário ao Bloom Filter
compras = user_data.item_id;
for i = 1:numel(compras)
    if any(strcmp(category_data.item_id, num2str(compras(i))))
        filtro(hash_function(num2str(compras(i)))) = true;
    end
end

% Filtrar produtos na categoria preferida (não comprados ainda)
recomendados = category_data;
recomendacoes_possiveis = [];

% Filtrar produtos que o usuário já comprou usando o Bloom Filter
for i = 1:height(recomendados)
    if ~filtro(hash_function(num2str(recomendados.item_id(i))))
        recomendacoes_possiveis = [recomendacoes_possiveis; recomendados(i,:)];
    end
end

% Ordenar os produtos recomendados com base na média de avaliações
media_ratings = grpstats(data, 'item_id', {'mean'}, 'DataVars', 'rating');
[~, idx_sorted] = sort(media_ratings.mean_rating, 'descend');

% Selecionar os 10 produtos mais bem classificados
top_10_produtos = media_ratings(idx_sorted(1:10), :);

% Exibir os top 10 produtos recomendados (da categoria predita)
disp('Top 10 Produtos recomendados (da categoria predita e não comprados):');
disp(top_10_produtos);
