clear

data = readtable('electronics.csv');

data = data(~any(ismissing(data), 2), {'user_id', 'item_id', 'category', 'rating', 'brand'});

% ---- NAIVE BAYES ----

% Seleciona um usuário aleatoriamente
alguem = unique(data.user_id);
alguem_em_especifico = alguem(randi(numel(alguem)));

% Transformar categorias em indices
[data.category_encoded, categories] = grp2idx(data.category);

% Filtrar os produtos comprados pelo usuário selecionado
user_data = data(data.user_id == alguem_em_especifico, :);

% Usar as compras do usuário para treinar o Naive Bayes
X = [user_data.rating];
y = user_data.category_encoded;
categories = unique(y);
P_class = histcounts(y, [categories; max(categories)+1]);
P_class = P_class / sum(P_class);
P_feature_given_class = cell(numel(categories), 1); 
for c = 1:numel(categories)
    idx = (y == categories(c)); 
    X_class = X(idx); 
    P_feature_given_class{c} = (histcounts(X_class, 1:6) + 1) / (numel(X_class) + 5);
end

% ---- PREVISÃO ----

Ic = 4.5; 
Ns = log(P_class);

for c = 1:numel(categories)
    feature_value = Ic(1);
    if feature_value > 0 && feature_value <= numel(P_feature_given_class{c})
        Ns(c) = Ns(c) + log(P_feature_given_class{c}(round(feature_value)));
    else
        Ns(c) = Ns(c) + log(1e-10);
    end
end

% Obter a categoria prevista
[~, predicted_category] = max(Ns);
nomes_categorias = unique(data.category);
nomes_previstos = nomes_categorias(predicted_category);
disp('Predicted Category: ');
disp(nomes_previstos);

% ---- Bloom Filter: Eliminar Produtos Já Comprados ----

% Inicializar o Bloom Filter para a categoria prevista
muito_bit = 1000; 
filtro = false(1, muito_bit); 
hash_function = @(x) mod(sum(double(x)), muito_bit) + 1;

% Filtrar os produtos da categoria prevista
category_data = data(strcmp(data.category, nomes_previstos), :);

% Adicionar os produtos já comprados do usuário ao Bloom Filter
compras = user_data.item_id;
for i = 1:numel(compras)
    if any(strcmp(category_data.item_id, num2str(compras(i))))
        filtro(hash_function(num2str(compras(i)))) = true;
    end
end

% Filtrar produtos na categoria preferida (não comprados ainda)
recomendados = category_data;
recomendacoes_possiveis = [];

% Filtrar produtos que o usuário já comprou usando o Bloom Filter
for i = 1:height(recomendados)
    if ~filtro(hash_function(num2str(recomendados.item_id(i))))
        recomendacoes_possiveis = [recomendacoes_possiveis; recomendados(i,:)];
    end
end

% Ordenar os produtos recomendados com base na média de avaliações
media_ratings = grpstats(data, 'item_id', {'mean'}, 'DataVars', 'rating');
[~, idx_sorted] = sort(media_ratings.mean_rating, 'descend');

% Selecionar os 10 produtos mais bem classificados
top_10_produtos = media_ratings(idx_sorted(1:10), :);

% Exibir os top 10 produtos recomendados (da categoria predita)
disp('Top 10 Produtos recomendados (da categoria predita e não comprados):');
disp(top_10_produtos);