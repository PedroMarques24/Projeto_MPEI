clear

data = readtable('electronics.csv');

data = data(~any(ismissing(data), 2), {'user_id', 'item_id', 'category', 'rating', 'brand'});

% ---- MINHASH ----
% Criar conjuntos de itens por usuário
alguem = unique(data.user_id);
num_users = numel(alguem);

set = cell(num_users, 1);
for i = 1:num_users
    set{i} = data.item_id(data.user_id == alguem(i));
end

% Parâmetros MinHash
num_hashes = 100;  
itens = unique(data.item_id);  
num_itens = numel(itens);

% Criar assinaturas MinHash
assinaturas = inf(num_hashes, num_users);

% Função de hash (simples, pode ser ajustada)
hash_functions = @(x, i) mod((7 * x + i), num_itens) + 1;

for f = 1:num_hashes
    for s = 1:num_users
        itens_set = set{s};
        hashed_values = arrayfun(@(x) hash_functions(x, f), itens_set);
        assinaturas(f, s) = min(hashed_values);
    end
end

% Função para calcular similaridade Jaccard usando MinHash
function similarity = compute_similarity(user1, user2, minhash_signatures, num_hashes)
    similarity = sum(minhash_signatures(:, user1) == minhash_signatures(:, user2)) / num_hashes;
end

% Selecionar o usuário escolhido aleatoriamente
alguem_em_especifico = randi(num_users);

% Calcular similaridade com os outros usuários
similarities = zeros(num_users, 1);
for ns = 1:num_users
    if ns ~= alguem_em_especifico
        similarities(ns) = compute_similarity(alguem_em_especifico, ns, assinaturas, num_hashes);
    else
        similarities(ns) = -1;
    end
end

% Encontrar os usuários mais similares (top 5)
[~, idx_users_parecidos] = sort(similarities, 'descend');
users_parecidos = idx_users_parecidos(1:5);

% Obter os produtos comprados pelos usuários mais similares
itens_recomendados = [];
for i = 1:numel(users_parecidos)
    similar_user = users_parecidos(i);
    itens_recomendados = [itens_recomendados; set{similar_user}];
end

% Excluir os produtos já comprados pelo usuário selecionado
user_purchased_itens = set{alguem_em_especifico};
itens_recomendados = setdiff(itens_recomendados, user_purchased_itens);

% Exibir os produtos recomendados
disp('ID dos produtos recomendados para o usuário com base em usuários similares (O dataset atual n tem nomes):');
disp(itens_recomendados);

% ---- RESULTADOS ----
% Exibir similaridade entre o usuário escolhido e os outros
disp(['Usuário selecionado: ', num2str(alguem_em_especifico)]);
for ola = 1:numel(users_parecidos)
    disp(['Similaridade com usuário ', num2str(users_parecidos(ola)), ': ', num2str(similarities(users_parecidos(ola)))]);
end
